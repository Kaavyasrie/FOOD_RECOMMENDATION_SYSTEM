import pandas as pd
from sklearn.tree import DecisionTreeClassifier
import pickle
import os

# Load dataset
data_path = 'data/food_mainfile.xlsx'
try:
    df = pd.read_excel(data_path)
except FileNotFoundError:
    print("Error: food_mainfile.xlsx not found in data/ folder.")
    exit(1)

# Preprocess data
def preprocess_data(df):
    df = df.copy()
    
    # Ensure numeric columns
    numeric_cols = ['Age', 'Cost_rs', 'Carbs_g', 'Protein_g', 'Fat_g', 'Calories']
    try:
        for col in numeric_cols:
            df[col] = pd.to_numeric(df[col], errors='coerce')
        df = df.dropna(subset=numeric_cols)
        if df.empty:
            print("Error: No valid data after cleaning numeric columns.")
            exit(1)
    except Exception as e:
        print(f"Error in numeric columns: {e}. Ensure {', '.join(numeric_cols)} are numeric.")
        exit(1)
    
    # Encode categorical variables
    df['Meal_type_code'] = df['Meal_type'].astype('category').cat.codes
    
    return df

df = preprocess_data(df)

# Features and target
X = df[['Age', 'Meal_type_code', 'Cost_rs', 'Carbs_g', 'Protein_g', 'Fat_g', 'Calories']]
y = df['Food_id']

# Train Decision Tree Classifier
model = DecisionTreeClassifier(random_state=42)
model.fit(X, y)

# Save model
os.makedirs('models', exist_ok=True)
with open('models/decision_tree_model.pkl', 'wb') as f:
    pickle.dump(model, f)

print("Model trained and saved successfully!")