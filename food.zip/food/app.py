import streamlit as st
import pandas as pd
import pickle
import numpy as np
import os
import re

# Custom CSS for styling
st.markdown("""
    <style>
    .main {
        background-color: #f0f2f6;
        padding: 20px;
    }
    .title {
        color: #ff4b4b;
        text-align: center;
        font-size: 36px;
        font-weight: bold;
    }
    .recommendation-card {
        background-color: #ffffff;
        border-radius: 10px;
        padding: 15px;
        margin-bottom: 15px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    .recommendation-title {
        color: #2e7d32;
        font-size: 24px;
        font-weight: bold;
    }
    .recommendation-text {
        color: #333333;
        font-size: 16px;
    }
    .sidebar .sidebar-content {
        background-color: #e0f7fa;
        padding: 10px;
    }
    .success-message {
        color: #388e3c;
        font-size: 18px;
        font-weight: bold;
    }
    </style>
""", unsafe_allow_html=True)

# Sidebar for inputs
st.sidebar.header("Enter Your Preferences 🍽️")
age = st.sidebar.number_input("Age (5-10 years)", min_value=5, max_value=10, value=5, step=1)
meal_type = st.sidebar.selectbox("Meal Type", ["Any", "Breakfast", "Lunch", "Dinner", "Snack"])
budget = st.sidebar.number_input("Budget (Rs)", min_value=1.0, value=50.0, step=1.0)

# Main content
st.markdown('<h1 class="title">Food Recommendation System for Kids</h1>', unsafe_allow_html=True)

# Load dataset and model
data_path = 'data/food_mainfile.xlsx'
try:
    df = pd.read_excel(data_path)
    st.write(f"Dataset loaded successfully, {len(df)} rows.")
except FileNotFoundError:
    st.error("Error: food_mainfile.xlsx not found in data/ folder.")
    st.stop()

model_path = 'models/decision_tree_model.pkl'
try:
    with open(model_path, 'rb') as f:
        model = pickle.load(f)
    st.write("Model loaded successfully.")
except FileNotFoundError:
    st.error("Error: decision_tree_model.pkl not found in models/ folder.")
    st.stop()

# Function to parse Estimated_Cost and compute total
def parse_estimated_cost(cost_str):
    try:
        costs = re.findall(r'(\d+)\s*Rs', str(cost_str))
        total = sum(int(cost) for cost in costs)
        return total
    except Exception as e:
        st.warning(f"Error parsing Estimated_Cost '{cost_str}': {e}")
        return 0

# Preprocess dataset
def preprocess_data(df):
    df = df.copy()
    original_rows = len(df)
    
    # Ensure numeric columns
    numeric_cols = ['Age', 'Cost_rs', 'Carbs_g', 'Protein_g', 'Fat_g', 'Calories']
    try:
        for col in numeric_cols:
            df[col] = pd.to_numeric(df[col], errors='coerce')
        invalid_rows = df[numeric_cols].isna().any(axis=1)
        if invalid_rows.any():
            dropped_rows = df[invalid_rows].index.tolist()
            df = df.dropna(subset=numeric_cols)
            st.warning(f"Dropped {len(dropped_rows)} rows with invalid numeric values: {dropped_rows}")
        if df.empty:
            st.error("Error: No valid data after cleaning numeric columns.")
            return None
    except Exception as e:
        st.error(f"Error in numeric columns: {e}. Ensure {', '.join(numeric_cols)} are numeric.")
        return None
    
    # Encode Meal_type
    df['Meal_type_code'] = df['Meal_type'].astype('category').cat.codes
    
    # Parse Estimated_Cost into a numeric column
    df['Estimated_Cost_Total'] = df['Estimated_Cost'].apply(parse_estimated_cost)
    invalid_costs = df[df['Estimated_Cost_Total'] == 0].index.tolist()
    if invalid_costs:
        st.warning(f"{len(invalid_costs)} rows have invalid Estimated_Cost values: {invalid_costs}")
    
    st.write(f"Final dataset size: {len(df)} rows")
    return df

processed_df = preprocess_data(df)
if processed_df is None:
    st.stop()

# Recommend meals
if st.button("Get Recommendations"):
    if age < 5 or age > 10:
        st.error("Age must be between 5 and 10 years.")
    elif budget <= 0:
        st.error("Budget must be positive.")
    else:
        # Filter dataset
        filtered_df = processed_df[(processed_df['Age'] == age) & (processed_df['Cost_rs'] <= budget)]
        if meal_type != 'Any':
            filtered_df = filtered_df[filtered_df['Meal_type'] == meal_type]

        if filtered_df.empty:
            st.warning("No meals found for the given criteria. Try increasing the budget or selecting 'Any' meal type.")
        else:
            # Prepare input for model
            features = ['Age', 'Meal_type_code', 'Cost_rs', 'Estimated_Cost_Total', 'Carbs_g', 'Protein_g', 'Fat_g', 'Calories']
            X = filtered_df[features]

            # Predict and select top 3 recommendations
            try:
                if hasattr(model, 'predict_proba'):
                    scores = model.predict_proba(X)[:, 1] if model.classes_.size > 1 else np.zeros(len(X))
                else:
                    scores = np.zeros(len(X))
                top_indices = np.argsort(scores)[-3:][::-1] if len(scores) > 3 else np.arange(len(scores))
                recommended_foods = filtered_df.iloc[top_indices][['Food_name', 'Description', 'Main_Ingredients', 'Carbs_g', 'Protein_g', 'Fat_g', 'Calories', 'Quantity', 'Cost_rs', 'Estimated_Cost_Total']]
            except Exception as e:
                st.warning(f"Error in prediction: {str(e)}. Using fallback recommendations.")
                recommended_foods = filtered_df[['Food_name', 'Description', 'Main_Ingredients', 'Carbs_g', 'Protein_g', 'Fat_g', 'Calories', 'Quantity', 'Cost_rs', 'Estimated_Cost_Total']].head(3)

            # Display recommendations
            st.header("Recommended Meals 🍴")
            for _, food in recommended_foods.iterrows():
                with st.container():
                    st.markdown(f"""
                        <div class="recommendation-card">
                            <h2 class="recommendation-title">{food['Food_name']} ({food['Quantity']})</h2>
                            <p class="recommendation-text"><b>Description:</b> {food['Description']}</p>
                            <p class="recommendation-text"><b>Ingredients:</b> {food['Main_Ingredients']}</p>
                            <p class="recommendation-text"><b>Nutrition:</b> Carbs: {food['Carbs_g']}g, Protein: {food['Protein_g']}g, Fat: {food['Fat_g']}g, Calories: {food['Calories']}kcal</p>
                            <p class="recommendation-text"><b>Estimated Cost:</b> {food['Estimated_Cost_Total']} Rs</p>
                            <p class="recommendation-text"><b>Total Cost:</b> {food['Cost_rs']} Rs</p>
                        </div>
                    """, unsafe_allow_html=True)
                    if st.button(f"Select {food['Food_name']}", key=food['Food_name']):
                        st.markdown(f'<p class="success-message">Great choice! {food["Food_name"]} sounds delicious! 🎉</p>', unsafe_allow_html=True)
                        st.write(f"**Description**: {food['Description']}")
                        st.write(f"**Ingredients**: {food['Main_Ingredients']}")
                        st.write(f"**Nutrition**: Carbs: {food['Carbs_g']}g, Protein: {food['Protein_g']}g, Fat: {food['Fat_g']}g, Calories: {food['Calories']}kcal")
                        st.write(f"**Estimated Cost**: {food['Estimated_Cost_Total']} Rs")
                        st.write(f"**Total Cost**: {food['Cost_rs']} Rs")
                        st.write("Have a happy meal! 😊")

# Display dataset (optional, for debugging)
if st.checkbox("Show Dataset"):
    st.write(processed_df)